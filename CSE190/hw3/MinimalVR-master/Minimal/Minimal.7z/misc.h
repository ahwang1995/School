#pragma once

// Std. Includes
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
// GL Includes
#include <GL/glew.h> // Contains all the necessery OpenGL includes
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
// A class for random functions we can use where ever!
class Misc {
public:
	// Prtins a matrix, useful for debugging!
	static void Misc::printMat(glm::mat4 M) {
		printf("[ %f, %f, %f, %f;\n %f, %f, %f, %f;\n %f, %f, %f, %f;\n %f, %f, %f, %f; ]\n",
			M[0][0], M[0][1], M[0][2], M[0][3],
			M[1][0], M[1][1], M[1][2], M[1][3],
			M[2][0], M[2][1], M[2][2], M[2][3],
			M[3][0], M[3][1], M[3][2], M[3][3]);
	}

	static void Misc::printVec(glm::vec3 v) {
		printf("[ %f, %f, %f ]\n",
			v.x, v.y, v.z);
	}

	static float Misc::random(float min, float max) {
		int accuracy = 1000;

		// Create a random number between 0 and (max - min) * 1000
		float r = rand() % accuracy * (max - min) + 1;
		// r is now between 0 and (max - min)
		r /= 1000.0f;
		// r is now between min and max
		r += min;

		return r;
	}
	static float Misc::pointLineDist(glm::vec3 lineA, glm::vec3 lineB, glm::vec3 point) {
		//float dist = (glm::cross((lineB-lineA),(lineA-point)))/(lineB-lineA)
	}

};